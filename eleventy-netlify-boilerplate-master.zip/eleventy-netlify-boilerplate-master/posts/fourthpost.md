---
title: This is the fourth example post
metaDescription: This is a sample meta description. If one is not present in
  your page/post's front matter, the default metadata.description will be used
  instead.
date: 2020-02-03
author: John Doe
summary: Why contemplating our mortality can be a powerful catalyst for change
tags:
  - environment
  - politics
---
Organically grow the holistic world view of disruptive innovation via workplace diversity and empowerment.

![A sample inlined image](https://source.unsplash.com/random/600x400)

Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition. Organically grow the holistic world view of disruptive innovation via workplace diversity and empowerment.
