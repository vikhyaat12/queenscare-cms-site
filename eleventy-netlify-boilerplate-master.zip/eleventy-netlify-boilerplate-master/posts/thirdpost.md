---
title: This is the third example post which has a slightly longer title than the others
metaDescription: This is a sample meta description. If one is not present in
  your page/post's front matter, the default metadata.description will be used
  instead.
date: 2020-01-01
author: Jane Doe
summary: Why contemplating our mortality can be a powerful catalyst for change
tags:
  - tech
  - politics
---
Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition. Organically grow the holistic world view of disruptive innovation via workplace diversity and empowerment.

```
pre,
code {
	line-height: 1.5;
}
```

Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation X is on the runway heading towards a streamlined cloud solution. User generated content in real-time will have multiple touchpoints for offshoring.

## Section Header

Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps. Nanotechnology immersion along the information highway will close the loop on focusing solely on the bottom line.
