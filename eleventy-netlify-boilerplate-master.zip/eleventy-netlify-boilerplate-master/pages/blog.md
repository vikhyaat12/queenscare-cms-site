---
layout: layouts/blog.njk
title: Blog
metaDescription: A sample Blog page listing various posts and authors.
date: 2017-01-01
permalink: /blog/index.html
eleventyNavigation:
  key: Blog
  order: 2
---
